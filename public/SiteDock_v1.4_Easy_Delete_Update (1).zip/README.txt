SITEDOCK v1.4 — EASY DELETE UPDATE

This update adds:
- A red trash button on every deployment card
- Manage Sites mode with checkboxes
- Select All / Clear Visible controls
- Bulk deletion of multiple deployments
- Confirmation before permanent deletion

INSTALL:
1. Open your GitHub repository.
2. Click the existing public folder.
3. Click Add file > Upload files.
4. Extract this ZIP on your computer.
5. Upload ONLY these three files from the extracted folder:
   - app.js
   - index.html
   - styles.css
6. Commit the changes to the main branch.
7. Render should redeploy automatically. If it does not, use Manual Deploy > Deploy latest commit.
8. When Render shows Live, hard-refresh SiteDock with Command + Shift + R.

Do not upload this ZIP itself to GitHub.
